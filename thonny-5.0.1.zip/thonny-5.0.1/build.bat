@echo off
setlocal
cd /d "%~dp0"

echo ========================================
echo Thonny source development setup
echo ========================================
echo.

where py >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python Launcher ^(py.exe^) was not found.
    echo Install Python 3.10 or newer and try again.
    exit /b 1
)

if not exist "venv\Scripts\python.exe" (
    echo Creating virtual environment...
    py -3 -m venv venv
    if errorlevel 1 (
        echo ERROR: Could not create the virtual environment.
        exit /b 1
    )
)

set "PY=venv\Scripts\python.exe"

echo Updating build tools...
"%PY%" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 exit /b 1

echo Installing formatting tools...
"%PY%" -m pip install isort black
if errorlevel 1 exit /b 1

echo Running isort...
"%PY%" -m isort thonny
if errorlevel 1 exit /b 1

echo Running black...
"%PY%" -m black thonny
if errorlevel 1 exit /b 1

echo.
echo ========================================
echo Source check completed successfully.
echo ========================================
echo.
echo NOTE: This script prepares/checks the source code.
echo It does not create the Windows installer.
echo For the Windows installer, run:
echo packaging\windows\create_installer.bat

endlocal
