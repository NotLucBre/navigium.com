"""
Easter-egg.
"""
